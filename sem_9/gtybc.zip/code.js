let tasks_block = document.querySelector('.tasks_block')

let isSorted = false;

const defaultFilter = (task) => true;
const isAsciveFilter = (task) => !task.isDone;
const filters = [defaultFilter, isAsciveFilter]
let taskFilter = defaultFilter;

const tasksFiltered = () => tasks.filter(taskFilter);

tasks = [
    {
        "text": "do task 1",
        "isDone": false
    },
    {
        "text": "do task 2",
        "isDone": false
    },
    {
        "text": "do task 3",
        "isDone": false
    }
]

const showTasks = () => {
    var temp = isSorted ? tasksFiltered().toSorted((a, b) => a.isDone - b.isDone) : tasksFiltered();
    
    str = ''
    if (temp.length == 0) {
        str += '<h2>Now no tasks</h2>'
    }
    else {
        str += '<h2>My to-do tasks</h2>'
        str += "<div class='list_tasks'>"
        temp.map((item, index) => {
            str += showTask(item, tasks.findIndex((element) => element == item))
            // console.log(item)
        })
        str += "</div>"
    }
    tasks_block.innerHTML = str;
}

const showTask = (task, index) => {
    return `
    <div class='task'>
    <div class="task_text_block">
    <span class="task_text ${task.isDone ? 'done' : 'not_done'}">${task.text}</span>
    </div>
    <div class="task_button_block">
    <button class="task_button" onclick="toggleTaskStatus(${index})">Toggle</button>
    <button class="task_button" onclick="showEditTaskDialog(${index})">Edit</button>
    <button class="task_button" onclick="deleteTask(${index})">Delete</button>
    </div>
    </div>
    `
}


const deleteTask = (id) => {
    tasks.splice(id, 1);
    showTasks();
}

const toggleTaskStatus = (id) => {
    tasks[id].isDone = !tasks[id].isDone;
    showTasks();
}

const showEditTaskDialog = (id) => {
    let box_update = document.querySelector('.edit_dialog')
    box_update.classList.remove("hidden")

    box_update.innerHTML = `
    <p>Input new text</p>
    <input type="text" id="new_value" value="${tasks[id].text}">
    <div>
    <button onclick="hideEditDialog()">Cancel</button>
    <button onclick="applyTaskChanges(${id})">Edit</button>
    </div>  
    `
}

const hideEditDialog = () => {
    let box_update = document.querySelector('.edit_dialog');
    box_update.classList.add("hidden");
}

const applyTaskChanges = (id) => {
    let box_update = document.querySelector('.edit_dialog');
    let new_value = document.querySelector('#new_value');
    
    tasks[id].text = new_value.value;
    
    box_update.classList.add("hidden");
    showTasks();
}


const toggleFilter = () => {
    let currIndex = filters.findIndex((filter) => taskFilter == filter);
    taskFilter = filters[(currIndex + 1) % filters.length];
    toggle_filter_btn.classList.remove("disabled_btn");
    toggle_filter_btn.classList.remove("enabled_btn");
    toggle_filter_btn.classList.add(taskFilter != defaultFilter ? "enabled_btn" : "disabled_btn");
    showTasks();
}

const toggleSort = () => {
    isSorted = !isSorted;
    toggle_sort_btn.classList.remove("disabled_btn");
    toggle_sort_btn.classList.remove("enabled_btn");
    toggle_sort_btn.classList.add(isSorted ? "enabled_btn" : "disabled_btn");
    showTasks();
}


const add_button = document.querySelector('#add_btn')
add_button.addEventListener('click', () => {
    let task_value = document.querySelector('#task_name')
    if (task_value.value.length == 0) {
        return;
    }

    tasks.push({
        "text": task_value.value,
        "isDone": false
    });
    showTasks();
    task_value.value = "";
})
const toggle_sort_btn = document.querySelector('#toggle_sort_btn');
toggle_sort_btn.addEventListener('click', toggleSort);

const toggle_filter_btn = document.querySelector('#toggle_filter_btn')
toggle_filter_btn.addEventListener('click', toggleFilter)

showTasks();